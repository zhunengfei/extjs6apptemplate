	Ext.onReady(function () {

		Ext.define('SearchField', {
			extend: 'Ext.form.FieldContainer',
			alias: 'widget.searchfield',
			layout: 'hbox',
			initComponent: function () {
				this.items = [
					{
						xtype: 'textfield',
						flex: 1,
						name: this.name,
						readOnly: this.readOnly,
						readOnlyCls: this.readOnlyCls
					},
					{
						xtype: 'splitter'
					},
					{
						xtype: 'button',
						text: 'Search'
					}
				];
				this.callParent();
			},
			getValue: function () {
				var items = this.items;
				return (items && items.length > 0) ? items[0].getValue() : null;
			},
			doSearch: function () {
				//override	
			}
		});

		Ext.define('PopRadioButtonGroup', {
			extend: 'Ext.form.RadioGroup',
			alias: 'widget.popRadiobuttongroup',
			columns: 2,
			//vertical: true,
			items: [
				{
					boxLabel: 'Yes',
					name: 'rb',
					inputValue: '1'
				},
				{
					boxLabel: 'No',
					name: 'rb',
					inputValue: '2',
					checked: true
				}

        ]
		});

		// The data store containing the list of states
		var states = Ext.create('Ext.data.Store', {
			fields: ['abbr', 'name'],
			data: [
				{
					"abbr": "AL",
					"name": "Alabama"
				},
				{
					"abbr": "AK",
					"name": "Alaska"
				},
				{
					"abbr": "AZ",
					"name": "Arizona"
				}
		    ]
		});

		var vbox1 = {
			layout: 'hbox',
			margin: 5,
			defaults: {
				border: false,
				readOnly: true,
				margin: 5,
				flex: 1,
				defaults: {
					margin: 5,
					readOnlyCls: 'readOnlyInputs',
					readOnly: true,
					labelAlign: 'right',
					labelWidth: 250
				}
			},
			items: [
				{
					layout: 'form',
					items: [{
							xtype: 'textfield',
							fieldLabel: 'Model',
							name: 'firstName'
					},
						{
							xtype: 'textfield',
							fieldLabel: 'Benifits Date/Last Hire Date/Termination Date',
							name: 'lastName'
                	}, {
							xtype: 'datefield',
							fieldLabel: 'Leave Status/Date',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Job Title/Officer Title/Grade',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'HR Gerneralist',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'NEMS EMployee',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Multiple Impact/Previous Termination Date',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'REgular/Temp Employee',
							name: 'lastName'
                	}]
				},
				{
					layout: 'form', 
					items: [{
							xtype: 'textfield',
							fieldLabel: 'Managed Segment LV4',
							name: 'firstName'
					}, {
							xtype: 'textfield',
							fieldLabel: 'GOC',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Managed Segment',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Managed Geography',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Legal Vehicle',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Legal Vehicle Geography',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Expat Indicator',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Base Salary/Currency',
							name: 'lastName'
                	}
                	]
				}
			]
		};


		var vbox3 = {
			layout: 'hbox',
			margin: 5,
			title: 'Special Payments',
			defaults: {
				border: false,
				margin: 5,
				flex: 1,
				labelAlign: 'right',
				labelWidth: 250
			},
			items: [{
				xtype: 'textfield',
				fieldLabel: 'Model ID',
				name: 'firstName',
				readOnlyCls: 'readOnlyInputs',
				readOnly: true
					}, {
				xtype: 'combo',
				fieldLabel: 'RIF Status',
				name: 'lastName',
				fieldLabel: 'Choose State',
				store: states,
				queryMode: 'local',
				displayField: 'name',
				valueField: 'abbr'

                	}, {
				xtype: 'textfield',
				fieldLabel: 'Model ID',
				name: 'firstName',
				readOnlyCls: 'readOnlyInputs',
				readOnly: true
					}]
		};

		var vbox4 = {
			layout: 'hbox',
			margin: 5,
			title: 'RIF Expense',
			defaults: {
				border: false,
				margin: '5 0 5 0',
				readOnly: true,
				flex: 1,
				defaults: {
					labelAlign: 'right',
					labelWidth: 250
				}
			},
			items: [{
				layout: 'vbox',
				items: [{
						xtype: 'fieldcontainer',
						layout: 'hbox',
						layout: 'hbox',
						margin: 5,
						fieldLabel: 'Notice Extension Days/Reason',
						items: [{
							xtype: 'checkbox',
							width: 20,
							name: 'lastName'
							}, {
							xtype: 'textfield',
							width: 170,
							name: 'lastName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
							}]
                	}, {
						xtype: 'fieldcontainer',
						layout: 'hbox',
						margin: 5,
						fieldLabel: 'Notice Extension Days/Reason',
						items: [{
							xtype: 'checkbox',
							width: 20,
							name: 'lastName'
							}, {
							xtype: 'textfield',
							width: 170,
							name: 'lastName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
							}]
                	}, {
						xtype: 'fieldcontainer',
						layout: 'hbox',
						margin: 5,
						fieldLabel: 'Notice Extension Days/Reason',
						items: [{
							xtype: 'checkbox',
							width: 20,
							name: 'lastName'
							}, {
							xtype: 'textfield',
							width: 170,
							name: 'lastName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
							}]
                	}, {
						xtype: 'fieldcontainer',
						layout: 'hbox',
						margin: 5,
						fieldLabel: 'Notice Extension Days/Reason',
						margin: '0 0 0 5',
						items: [{
							xtype: 'checkbox',
							width: 20,
							name: 'lastName'
							}, {
							xtype: 'textfield',
							width: 170,
							name: 'lastName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
							}]
                	}

				]
			}, {
				layout: 'vbox',
				items: [{
						xtype: 'fieldcontainer',
						layout: 'hbox',
						layout: 'hbox',
						margin: 5,
						fieldLabel: 'Notice Extension Days/Reason',
						items: [{
							xtype: 'checkbox',
							width: 20,
							name: 'lastName'
							}, {
							xtype: 'textfield',
							width: 170,
							name: 'lastName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
							}]
                	}, {
						xtype: 'fieldcontainer',
						layout: 'hbox',
						margin: 5,
						fieldLabel: 'Notice Extension Days/Reason',
						items: [{
							xtype: 'checkbox',
							width: 20,
							name: 'lastName'
							}, {
							xtype: 'textfield',
							width: 170,
							name: 'lastName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
							}]
                	}, {
						xtype: 'fieldcontainer',
						layout: 'hbox',
						margin: 5,
						fieldLabel: 'Notice Extension Days/Reason',
						items: [{
							xtype: 'checkbox',
							width: 20,
							name: 'lastName'
							}, {
							xtype: 'textfield',
							width: 170,
							name: 'lastName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
							}]
                	}, {
						xtype: 'fieldcontainer',
						layout: 'hbox',
						margin: 5,
						fieldLabel: 'Notice Extension Days/Reason',
						margin: '0 0 0 5',
						items: [{
							xtype: 'checkbox',
							width: 20,
							name: 'lastName'
							}, {
							xtype: 'textfield',
							width: 170,
							name: 'lastName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
							}]
                	}

				]
			}]
		};

		var vbox2 = {
			layout: 'hbox',
			margin: 5,
			defaults: {
				border: false,
				readOnly: true,
				flex: 1,
				defaults: {
					labelAlign: 'right',
					labelWidth: 250
				}
			},
			items: [
				{
					layout: 'form',
					items: [{
							xtype: 'textfield',
							fieldLabel: 'Model ID',
							name: 'firstName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
					},
						{
							xtype: 'textfield',
							fieldLabel: 'Serverance Policy ID / Effective Date',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true,
							name: 'lastName'
                	}, {
							xtype: 'text',
							fieldLabel: '*Reserve ID',
							name: 'lastName'
                	}, {
							xtype: 'combo',
							fieldLabel: 'RIF Status',
							name: 'lastName',
							fieldLabel: 'Choose State',
							store: states,
							queryMode: 'local',
							displayField: 'name',
							valueField: 'abbr'

                	}, {
							xtype: 'combo',
							fieldLabel: 'RIF Status',
							name: 'lastName',
							fieldLabel: 'Category',
							store: states,
							queryMode: 'local',
							displayField: 'name',
							valueField: 'abbr'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Finance Action (Project ID)',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'HRSD Rep',
							name: 'lastName'
                	}, {
							xtype: 'searchfield',
							fieldLabel: 'HR Coordinating GEID',
							name: 'customName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'HRSD Case#',
							name: 'lastName'
                	}, {

							xtype: 'popRadiobuttongroup',
							fieldLabel: 'Approved RIF Volunteer',
							name: 'lastName'
                	}, {
							xtype: 'datefield',
							fieldLabel: 'RIF Volunteer Conversation Date',
							name: 'lastName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true
                	}, {
							xtype: 'searchfield',
							fieldLabel: 'RIF Volunteer Manager GEID',
							name: 'customName',
							readOnlyCls: 'readOnlyInputs',
							readOnly: true,
                	}, {
							xtype: 'searchfield',
							fieldLabel: 'Letter Signatory Override GEID',
							name: 'customName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Comments',
							name: 'lastName'
                	}]
				}, {
					layout: 'form',
					items: [{
							xtype: 'textfield',
							fieldLabel: '*Model Name',
							name: 'firstName'
					}, {
							xtype: 'popRadiobuttongroup',
							fieldLabel: 'Mutual Agreement',
							name: 'lastName'
                	}, {
							xtype: 'datefield',
							fieldLabel: '*Notice Start Date',
							name: 'lastName'
                	}, {
							xtype: 'datefield',
							fieldLabel: '*Last Day Worked',
							name: 'lastName'
                	}, {
							xtype: 'fieldcontainer',
							layout: 'hbox',
							fieldLabel: 'Notice Extension Days/Reason',
							items: [{
								xtype: 'textfield',
								width: 40,
								name: 'lastName'
							}, {
								xtype: 'splitter'
							}, {
								xtype: 'combo',
								width: 20,
								store: states,
								flex: 1,
								name: 'lastName'
							}]
                	}, {
							xtype: 'datefield',
							fieldLabel: 'Estimated Termination Date',
							name: 'lastName',
							readOnly: true,
							readOnlyCls: 'readOnlyInputs'
                	}, {
							xtype: 'datefield',
							fieldLabel: 'Estimated Termination Effective Date',
							name: 'lastName'
                	}, {
							xtype: 'datefield',
							fieldLabel: 'Annoucement Date',
							name: 'lastName'
                	}, {
							xtype: 'popRadiobuttongroup',
							fieldLabel: 'Signed Agreement Recieved',
							name: 'lastName'
                	}, {
							xtype: 'datefield',
							fieldLabel: 'Signed Agreement Recieved Date',
							name: 'lastName',
							readOnly: true,
							readOnlyCls: 'readOnlyInputs'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Remaining Vacation Days',
							name: 'lastName'
                	}, {
							xtype: 'datefield',
							fieldLabel: 'Re-deployed Date',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							fieldLabel: 'Re-deployed Comments',
							name: 'lastName'
                	}
                	]
				},
				{
					//COL 3 
					layout: 'form',margin: 5,
					defaults: {
						xtype: 'popRadiobuttongroup',
						labelAlign: 'right',
						labelWidth: 250
					},
					items: [{
							fieldLabel: 'Salary Continuation',
							name: 'firstName'
					}, {

							fieldLabel: 'Paid Pregnacy Leave(PPL)',
							name: 'lastName'
                	}, {

							fieldLabel: 'Employment will terminate immediately',
							name: 'lastName'
                	}, {

							fieldLabel: 'OWEPA(Exhibit A) Not Appliction',
							name: 'lastName'
                	}, {

							fieldLabel: 'Working Notice',
							name: 'lastName'
                	}, {

							fieldLabel: 'SRA(LSX)',
							name: 'lastName'
                	}, {

							fieldLabel: 'Location strategy initiative',
							name: 'lastName'
                	}, {

							fieldLabel: 'Position To Be Replaced',
							name: 'lastName'
                	}, {

							fieldLabel: 'Linked Account',
							name: 'lastName'
                	}, {
							xtype: 'checkbox',
							fieldLabel: 'Linked Account Activated',
							name: 'lastName'
                	}, {
							xtype: 'textfield',
							readOnly: true,
							readOnlyCls: "readOnlyInputs",
							fieldLabel: 'Personal Email Address',
							name: 'lastName',
                	}
                	]
				}
			]
		};

		Ext.define('PopulationDetails', {
			extend: 'Ext.form.FormPanel',
			title: 'Employee Indicative Data',
			alias: ['widget.pupulationdetails'],
			margin: 5,
			defaults: {
				layout: 'fit',
				border: false,margin: '0 10 0 0'
			},
			items: [{				
				items: vbox1
			}, {				
				items: vbox2
			}, {
				items: vbox3
			}, {
				items: vbox4
			}]
		});

		Ext.create('PopulationDetails', {
			renderTo: Ext.getBody()
		});
	});