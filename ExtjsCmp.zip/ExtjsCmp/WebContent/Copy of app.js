Ext.Loader.setConfig({
	enabled : true
});
Ext.require([ 'Ext.grid.*', 'Ext.data.*', 'Ext.util.*', 'Ext.toolbar.Paging',
		'Ext.ModelManager', 'Ext.tip.QuickTipManager' ]);

Ext.onReady(function() {
	Ext.override(Ext.data.proxy.Ajax, {
						
		
		doRequest : function(operation, callback, scope) {
			var writer = this.getWriter(), request = this.buildRequest(
					operation, callback, scope);
			if (operation.allowWrite()) {
				request = writer.write(request);
			}
			Ext.apply(request, {
				headers : this.headers,
				timeout : this.timeout,
				scope : this,
				callback : this.createRequestCallback(request, operation,
						callback, scope),
				method : this.getMethod(request),
				jsonData : this.jsonData,
				disableCaching : false
			// explicitly set it to false, ServerProxy handles caching
			});

			// Added... jsonData is handled already
			if (this.jsonData) {

				request.jsonData = Ext.encode(request.params);
				delete request.params;
			}

			window.request = request;
			window.jd = Ext.JSON.decode(request.jsonData);

			request.jsonData = {
				crap : request.jsonData
			};

			Ext.Ajax.request(request);
			return request;
		}
	});

	Ext.tip.QuickTipManager.init();
	Ext.define('ForumThread', {
		extend : 'Ext.data.Model',
		fields : [ 'one', 'two', 'three' ]
	});
	var store = Ext.create('Ext.data.Store', {
		pageSize : 5,
		model : 'ForumThread',
		remoteSort : true,
		proxy : {

			type : 'ajax',
			method : 'POST',
			paramsAsJson : true,
			actionMethods : {
				read : 'POST'
			},
			url : 'r.jsp',
			reader : {
				root : 'data',
				type : 'json',
				totalProperty : 'total'
			},
			writer : {
				type : 'json'
			},
			simpleSortMode : true
		},
		listeners : {
			beforeload : function(store, operation, eOpts) {
				store.proxy.jsonData = {};
			}
		}

	});

	function renderLast(value, p, r) {
		return Ext.String.format('{0}<br/>by {1}', Ext.Date.dateFormat(value,
				'M j, Y, g:i a'), r.get('lastposter'));
	}

	var pluginExpanded = true;
	var grid = Ext.create('Ext.grid.Panel', {
		width : 300,
		height : 300,
		title : 'ExtJS.com - Browse Forums',
		store : store,
		disableSelection : true,
		loadMask : true,
		viewConfig : {
			trackOver : false,
			stripeRows : false
		},
		// grid columns
		columns : [ {
			id : 'one',
			text : "One",
			dataIndex : 'one',
			width : 100,
			// renderer: renderTopic,
			sortable : false
		}, {
			text : "Two",
			dataIndex : 'two',
			width : 100,
			sortable : true
		}, {
			text : "Three",
			dataIndex : 'three',
			flex : 1,
			align : 'right',
			sortable : true
		} ],
		// paging bar on the bottom
		bbar : Ext.create('Ext.PagingToolbar', {
			store : store,
			displayInfo : true,
			displayMsg : 'Displaying topics {0} - {1} of {2}',
			emptyMsg : "No topics to display",
			inputItemWidth : 35
		}),
		renderTo : 'c'
	});

	// trigger the data store load
	store.load({
		params : {
			searchData : {
				a : 1
			},
			pageData : {
				b :  2
			}
		}
	});
});