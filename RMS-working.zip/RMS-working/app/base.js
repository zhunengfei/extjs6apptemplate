require.config({
	paths: {
		"app": '../app',
		"underscore": "vendor-lib/underscore/underscore-min",
		"common-all":"resources/global/js/common-all"
	}
});
require(["common-all","override/window"]);
