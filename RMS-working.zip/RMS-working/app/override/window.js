define(function() {
	window.l = function (a) {
		console.log(a);
	}
	window.i = function (a) {
		console.info(a);
	}
	window.w = function (a) {
		console.warn(a);
	}
	window.a = function (a) {
		alert(a);
	}
});