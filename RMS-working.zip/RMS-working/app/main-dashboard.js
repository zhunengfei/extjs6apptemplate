require(["base"], function () {
	require(['src/dashboard/modOne']);		
});