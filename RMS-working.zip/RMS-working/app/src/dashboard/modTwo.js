define(function () {
	return {
		name: "This is module two"
	}
});