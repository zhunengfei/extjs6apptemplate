require(["base"], function () {
	require(['src/dashboard/main']);			
});