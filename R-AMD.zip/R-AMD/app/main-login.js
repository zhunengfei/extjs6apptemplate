require(["src/modTwo","override/window"], function (mod) {
	console.log("On login page");
});