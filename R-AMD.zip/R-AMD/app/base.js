require.config({
	paths: {
		"app": '../app',
		"underscore": "vendor-lib/underscore/underscore-min"
	},
	shim:{
		"underscore":{
			"exports" : "_"
		}
	}
});

require(["override/window"]);
