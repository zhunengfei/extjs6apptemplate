define(function() {
	//private code	
		console.log("Loading modTwo in modZero");	
		return {
			name: "This is module zero"
		}
		
});