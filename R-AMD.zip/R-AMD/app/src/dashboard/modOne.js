define(["underscore"], function (_) {
	//private code

	_.map([1, 2, 3], function (num) {
		console.log(num);
	});
	
	l('loading dashboard modules...');

	return {
		name: "This is module one"
	}
});